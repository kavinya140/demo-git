package com.example.demo;

import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/students")
public class StudentController {

    private List<Student> students = new ArrayList<>();

    // ✅ GET - Get all students
    @GetMapping
    public List<Student> getAllStudents() {
        return students;
    }

    // ✅ POST - Add new student
    @PostMapping
public String addStudent(@RequestBody Student student) {
    students.add(student);
    return "Student added successfully!";
}

    // ✅ GET by ID
    @GetMapping("/{id}")
    public Student getStudentById(@PathVariable int id) {
        return students.stream()
                .filter(s -> s.getId() == id)
                .findFirst()
                .orElse(null);
    }

    // ✅ DELETE by ID
    @DeleteMapping("/{id}")
    public String deleteStudent(@PathVariable int id) {
        students.removeIf(s -> s.getId() == id);
        return "Student deleted successfully!";
    }
}

