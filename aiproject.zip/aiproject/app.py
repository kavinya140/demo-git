from flask import Flask, render_template, request, jsonify
import random

app = Flask(__name__)

# ------------------------
# Simple AI Logic (Demo)
# ------------------------

def generate_summary(text):
    return text[:200] + "..." if len(text) > 200 else text

def generate_flashcards(text):
    sentences = text.split(".")
    flashcards = []
    for s in sentences[:5]:
        if len(s.strip()) > 10:
            flashcards.append({
                "question": "Explain:",
                "answer": s.strip()
            })
    return flashcards

def generate_quiz(text):
    words = text.split()
    questions = []
    for i in range(3):
        if len(words) > 5:
            answer = random.choice(words)
            questions.append({
                "question": f"What word appeared in the text?",
                "options": [answer, "AI", "Python", "Data"],
                "answer": answer
            })
    return questions

def generate_concept_map(text):
    words = list(set(text.split()))
    return words[:10]

# ------------------------
# Routes
# ------------------------

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/process", methods=["POST"])
def process():
    data = request.json
    text = data.get("text")

    result = {
        "summary": generate_summary(text),
        "flashcards": generate_flashcards(text),
        "quiz": generate_quiz(text),
        "concepts": generate_concept_map(text)
    }

    return jsonify(result)

if __name__ == "__main__":
    app.run(debug=True)
